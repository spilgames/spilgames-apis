package com.spilgames.examples.ui;

import android.app.Activity;
import android.os.Bundle;

import com.spilgames.examples.R;

public class SecondActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);
	}

}
