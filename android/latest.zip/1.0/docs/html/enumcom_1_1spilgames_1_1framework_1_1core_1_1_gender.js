var enumcom_1_1spilgames_1_1framework_1_1core_1_1_gender =
[
    [ "FEMALE", "enumcom_1_1spilgames_1_1framework_1_1core_1_1_gender.html#a4e47651595984c232374856bf0c38b2d", null ],
    [ "MALE", "enumcom_1_1spilgames_1_1framework_1_1core_1_1_gender.html#a73ec722c451b28a79b49e2c67f3bc92e", null ]
];