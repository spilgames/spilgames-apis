var classcom_1_1spilgames_1_1framework_1_1_spil_application =
[
    [ "getSpilInstance", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html#a00626f3e421f8c031082dd330996b403", null ],
    [ "onActivityCreated", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html#af54c3b5f12f20987520db3b4646b8608", null ],
    [ "onActivityDestroyed", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html#a9a090979442829bbd31489cfe3c4154b", null ],
    [ "onActivityPaused", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html#acfd3de92e6ed07d95a950e4bd8b3a330", null ],
    [ "onActivityResumed", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html#ad9b6e913e5804d1179a36d297a57bd5d", null ],
    [ "onActivitySaveInstanceState", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html#a673922befdab3c6c8647798135fbfba3", null ],
    [ "onActivityStarted", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html#a6e2cc2d3a4fc58d6a025c92268a65dd7", null ],
    [ "onActivityStopped", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html#af9474c307f1e11184d73bbd0deee37ec", null ],
    [ "onCreate", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html#a4fa171791b7fd07ff9480df3e83daee6", null ]
];