var hierarchy =
[
    [ "com.spilgames.framework.data.managers.ConfigurationsManager.ConfigurationManagerListener", "interfacecom_1_1spilgames_1_1framework_1_1data_1_1managers_1_1_configurations_manager_1_1_configuration_manager_listener.html", [
      [ "com.spilgames.framework.Spil", "classcom_1_1spilgames_1_1framework_1_1_spil.html", null ]
    ] ],
    [ "com.spilgames.framework.data.Configurations", "classcom_1_1spilgames_1_1framework_1_1data_1_1_configurations.html", null ],
    [ "com.spilgames.framework.data.dao.ConfigurationsDAO", "interfacecom_1_1spilgames_1_1framework_1_1data_1_1dao_1_1_configurations_d_a_o.html", [
      [ "com.spilgames.framework.data.dao.impl.WebConfigurationsDAO", "classcom_1_1spilgames_1_1framework_1_1data_1_1dao_1_1impl_1_1_web_configurations_d_a_o.html", null ]
    ] ],
    [ "com.spilgames.framework.data.managers.ConfigurationsManager", "interfacecom_1_1spilgames_1_1framework_1_1data_1_1managers_1_1_configurations_manager.html", [
      [ "com.spilgames.framework.data.managers.impl.ConfigurationsManagerImpl", "classcom_1_1spilgames_1_1framework_1_1data_1_1managers_1_1impl_1_1_configurations_manager_impl.html", null ]
    ] ],
    [ "com.spilgames.framework.core.parser.json.impl.ConfigurationsParser", "classcom_1_1spilgames_1_1framework_1_1core_1_1parser_1_1json_1_1impl_1_1_configurations_parser.html", null ],
    [ "com.spilgames.framework.core.server.FrameworkUrlHelper", "classcom_1_1spilgames_1_1framework_1_1core_1_1server_1_1_framework_url_helper.html", null ],
    [ "com.spilgames.framework.core.Gender", "enumcom_1_1spilgames_1_1framework_1_1core_1_1_gender.html", null ],
    [ "com.spilgames.framework.core.SpilConstants", "classcom_1_1spilgames_1_1framework_1_1core_1_1_spil_constants.html", null ],
    [ "com.spilgames.framework.tracking.SpilTracker", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html", [
      [ "com.spilgames.framework.tracking.impl.BaseTracker", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html", null ],
      [ "com.spilgames.framework.tracking.impl.FlurryTracker", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_flurry_tracker.html", null ],
      [ "com.spilgames.framework.tracking.impl.GoogleAnalyticsTracker", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_google_analytics_tracker.html", null ],
      [ "com.spilgames.framework.tracking.impl.SetTracker", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html", null ]
    ] ],
    [ "com.spilgames.framework.core.parser.json.impl.TrackingParser", "classcom_1_1spilgames_1_1framework_1_1core_1_1parser_1_1json_1_1impl_1_1_tracking_parser.html", null ],
    [ "com.spilgames.framework.core.server.UrlConstants", "classcom_1_1spilgames_1_1framework_1_1core_1_1server_1_1_url_constants.html", null ],
    [ "ActivityLifecycleCallbacks", null, [
      [ "com.spilgames.framework.SpilApplication", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html", null ]
    ] ],
    [ "Application", null, [
      [ "com.spilgames.framework.SpilApplication", "classcom_1_1spilgames_1_1framework_1_1_spil_application.html", null ]
    ] ],
    [ "UnityPlayerActivity", null, [
      [ "com.spilgames.framework.Spil", "classcom_1_1spilgames_1_1framework_1_1_spil.html", null ]
    ] ]
];