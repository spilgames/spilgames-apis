var annotated =
[
    [ "com", null, [
      [ "spilgames", null, [
        [ "framework", null, [
          [ "environment", null, [
            [ "DevEnvironment", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_environment.html", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_environment" ],
            [ "DevStores", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores.html", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores" ]
          ] ],
          [ "listeners", null, [
            [ "AdsListener", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener" ]
          ] ],
          [ "SpilInterface", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface" ]
        ] ]
      ] ]
    ] ]
];