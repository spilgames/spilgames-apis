var classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker =
[
    [ "SetTracker", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#ac724ad59e0cfee504e31913eb04412a0", null ],
    [ "getSpilTracker", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#a3f91615a4d1b7c8fccba4a26de413991", null ],
    [ "onStartTracking", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#ab8f6ee8783682e5a6b63046e1735d053", null ],
    [ "onStopTracking", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#a609b8f0fd405f81dca81c2f589c88fe4", null ],
    [ "trackAge", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#aebc0017f2ef8493db7d09f541e0ab12b", null ],
    [ "trackEndTimedEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#aaa9a0f3a670c3ebbd088437d878b64b4", null ],
    [ "trackEndTimedEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#ac55aa7a4db0591e6b3a0422be81d36ba", null ],
    [ "trackError", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#a29ffb13d90bb56790a590a0b871f2faa", null ],
    [ "trackEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#afef400a7d95b605583a9de9db667ede8", null ],
    [ "trackEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#aa5f1b0c1efa0f6ba2bc654058497ad5e", null ],
    [ "trackEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#aa607da9d32327c737206b5f7d3a67e7c", null ],
    [ "trackEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#a240889aa53ce1045a896b648ccdce7c6", null ],
    [ "trackGender", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#a143d85ca51cda371ab507e2245173bf0", null ],
    [ "trackLocation", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#a0b34b5091b4c6afbd55c011282dbe2e1", null ],
    [ "trackPage", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#a19ee578afe6d27751a417ec4bb135cc6", null ],
    [ "trackTimedEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#ae44e4ab6e4dd30b63a5a601202253da6", null ],
    [ "trackUserId", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_set_tracker.html#a11c79d6c05f1c30fc5cd09a7f2fe29a3", null ]
];