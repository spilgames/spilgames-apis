var searchData=
[
  ['gender',['Gender',['../enumcom_1_1spilgames_1_1framework_1_1core_1_1_gender.html',1,'com::spilgames::framework::core']]],
  ['googleanalyticstracker',['GoogleAnalyticsTracker',['../classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_google_analytics_tracker.html',1,'com::spilgames::framework::tracking::impl']]]
];
