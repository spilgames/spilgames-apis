var searchData=
[
  ['onadsfailedtoload',['onAdsFailedToLoad',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#a885145e7e91a52250dc5f59670de9491',1,'com::spilgames::framework::listeners::AdsListener']]],
  ['onadsloaded',['onAdsLoaded',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#a9f16bdb7304700415f87801df495d5ee',1,'com::spilgames::framework::listeners::AdsListener']]]
];
