var classcom_1_1spilgames_1_1framework_1_1data_1_1dao_1_1impl_1_1_web_configurations_d_a_o =
[
    [ "WebConfigurationsDAO", "classcom_1_1spilgames_1_1framework_1_1data_1_1dao_1_1impl_1_1_web_configurations_d_a_o.html#af86e9962a1c22df78b8e5915c1e77bfa", null ],
    [ "retrieveConfigurations", "classcom_1_1spilgames_1_1framework_1_1data_1_1dao_1_1impl_1_1_web_configurations_d_a_o.html#a917475b5ec1000c1247cebc7139230d9", null ]
];