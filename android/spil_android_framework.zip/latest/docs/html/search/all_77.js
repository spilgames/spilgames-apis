var searchData=
[
  ['webconfigurationsdao',['WebConfigurationsDAO',['../classcom_1_1spilgames_1_1framework_1_1data_1_1dao_1_1impl_1_1_web_configurations_d_a_o.html',1,'com::spilgames::framework::data::dao::impl']]]
];
