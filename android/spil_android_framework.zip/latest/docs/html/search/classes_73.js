var searchData=
[
  ['spilinterface',['SpilInterface',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html',1,'com::spilgames::framework']]]
];
