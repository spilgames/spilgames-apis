var searchData=
[
  ['nullhostexception',['NullHostException',['../classcom_1_1spilgames_1_1framework_1_1core_1_1errorhandling_1_1exceptions_1_1_null_host_exception.html',1,'com::spilgames::framework::core::errorhandling::exceptions']]]
];
