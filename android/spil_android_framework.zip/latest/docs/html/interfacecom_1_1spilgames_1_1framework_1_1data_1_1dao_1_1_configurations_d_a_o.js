var interfacecom_1_1spilgames_1_1framework_1_1data_1_1dao_1_1_configurations_d_a_o =
[
    [ "retrieveConfigurations", "interfacecom_1_1spilgames_1_1framework_1_1data_1_1dao_1_1_configurations_d_a_o.html#a7da18f709873764221307023f2718e97", null ]
];