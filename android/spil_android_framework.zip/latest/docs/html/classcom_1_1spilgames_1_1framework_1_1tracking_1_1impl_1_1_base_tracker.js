var classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker =
[
    [ "BaseTracker", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a6aa1b67f4c17013e16ce6f777c8c36a4", null ],
    [ "getTrackers", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a463efab11e4cc83218ecbbb65ff81d4a", null ],
    [ "onStartTracking", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#af52c9170b32c2780584f5c2bd8f08d56", null ],
    [ "onStopTracking", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a17f4ffb08dd6a60893f7dd227422e016", null ],
    [ "trackAge", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#ae7e862518960ef0eda497f5c680b3c9e", null ],
    [ "trackEndTimedEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a9d6f0d48391512946136e4da693c6269", null ],
    [ "trackEndTimedEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#ac044eeeeec9083b9b8909fedc3c705e1", null ],
    [ "trackError", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#aa07e953231e8660893a527c44be1dc30", null ],
    [ "trackEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#aa08cdd5e1211f173a7e37d073e309cf3", null ],
    [ "trackEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#addb5c25d03b4b849512c3bca4d98400f", null ],
    [ "trackEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a9448883272dee0414a6a9ce891e6a8dc", null ],
    [ "trackEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#adeda7bcb92163b1a43af2696446bb551", null ],
    [ "trackGender", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a633c6db76772795f8f67b3a28715ce4e", null ],
    [ "trackLocation", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a83193acc443d222bafd4653c7e762f7c", null ],
    [ "trackPage", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a53b3107dbcf4a954715842acb4b700d9", null ],
    [ "trackTimedEvent", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a788759a2cbfea02eab8e8e322f20553f", null ],
    [ "trackUserId", "classcom_1_1spilgames_1_1framework_1_1tracking_1_1impl_1_1_base_tracker.html#a9e262e501c7dc46619b6b02581bff6df", null ]
];