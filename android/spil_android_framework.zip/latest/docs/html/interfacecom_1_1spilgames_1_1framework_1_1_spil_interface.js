var interfacecom_1_1spilgames_1_1framework_1_1_spil_interface =
[
    [ "onAdsDestroy", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a93635f92bbad2bb3e19d1afed5c0917d", null ],
    [ "onAdsStart", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#ab766193f7df06259e33050da1a741f20", null ],
    [ "onAdsStop", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#ad78396cd8990190c60d7bb2769e34f55", null ],
    [ "onStartTracking", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a797262e1dd90c089a5fe20819d9a1b34", null ],
    [ "onStopTracking", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#ad3639f8ca79bd77c748ec51dd9e1d2eb", null ],
    [ "setAdsListener", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a10c6759ad1a64350f5e33e4f15e1e032", null ],
    [ "showInterstitial", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a71fc6657a71133af726ee9e4d625c456", null ],
    [ "start", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a877454c856a8a733a4386b97bd02fc91", null ],
    [ "trackEndTimedEvent", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a39ebb5cad25cd07d5d29404c47ebc6f3", null ],
    [ "trackEndTimedEvent", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a74dd4dbd6931062a5def531188ac2af1", null ],
    [ "trackError", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a788240005fa3c701d0f240b7a3f106dd", null ],
    [ "trackEvent", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#aebc9770babf0ace23b5211271fe984ef", null ],
    [ "trackEvent", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#abd363b62c3c4b9b2d2844052e3c26de5", null ],
    [ "trackEvent", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a091aef400daed9e47eedb4f323ff2210", null ],
    [ "trackEvent", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#ac116c06232ab1bfdeca2baa808ac61e1", null ],
    [ "trackPage", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a9cee121bcf7f5f32afc04da225cd3187", null ],
    [ "trackTimedEvent", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#ac243cde722aef4275871c051454cbac8", null ],
    [ "trackUserId", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#aae8d97a58bb682e896e1357a37fa3cda", null ]
];