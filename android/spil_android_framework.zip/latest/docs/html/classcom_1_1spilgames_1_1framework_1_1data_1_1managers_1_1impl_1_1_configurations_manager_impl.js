var classcom_1_1spilgames_1_1framework_1_1data_1_1managers_1_1impl_1_1_configurations_manager_impl =
[
    [ "ConfigurationsManagerImpl", "classcom_1_1spilgames_1_1framework_1_1data_1_1managers_1_1impl_1_1_configurations_manager_impl.html#a567bf84d5bb648487330427abe166b99", null ],
    [ "getConfigurations", "classcom_1_1spilgames_1_1framework_1_1data_1_1managers_1_1impl_1_1_configurations_manager_impl.html#acbe9f358ffd36ccec1a3f29b0838db6b", null ]
];