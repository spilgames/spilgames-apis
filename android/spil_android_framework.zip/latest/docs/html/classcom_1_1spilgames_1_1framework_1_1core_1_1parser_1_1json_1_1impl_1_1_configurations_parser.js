var classcom_1_1spilgames_1_1framework_1_1core_1_1parser_1_1json_1_1impl_1_1_configurations_parser =
[
    [ "parse", "classcom_1_1spilgames_1_1framework_1_1core_1_1parser_1_1json_1_1impl_1_1_configurations_parser.html#a99c1b7011ca654e712a7cb0d9381c251", null ]
];