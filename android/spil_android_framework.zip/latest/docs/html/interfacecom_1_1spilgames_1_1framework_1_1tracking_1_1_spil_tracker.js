var interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker =
[
    [ "onStartTracking", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a3654217d53f9968ba0c9cb1435687619", null ],
    [ "onStopTracking", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#ac9409a72c38f57aec3fbfa010769927c", null ],
    [ "trackAge", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#aa9f82592d9d378037fc415b7204391d2", null ],
    [ "trackEndTimedEvent", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a7d567e66629c50aabad6e93be56d0eb2", null ],
    [ "trackEndTimedEvent", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a758d593e31e8a4196dd8f3e1ff234baa", null ],
    [ "trackError", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#affa6f119d5eb82b22e234d54dba21128", null ],
    [ "trackEvent", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a08e853a0745b4f560d4d4602dccc7f1e", null ],
    [ "trackEvent", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a75c79d2cccef52507e8fcbb87c901c72", null ],
    [ "trackEvent", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a22b7c0f7672e7fae826a0ac35019e2a9", null ],
    [ "trackEvent", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a53bb2b3b188c68a5833eb29f1aa6b44b", null ],
    [ "trackGender", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#af40b59697203682827f141552f55f646", null ],
    [ "trackLocation", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a6332155661c56c2c8a682ac6c0c6fc6a", null ],
    [ "trackPage", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a90e3126a25d90f37e2a28a2f84614e4e", null ],
    [ "trackTimedEvent", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a210d654966324e4d56cb0d00d1cee93f", null ],
    [ "trackUserId", "interfacecom_1_1spilgames_1_1framework_1_1tracking_1_1_spil_tracker.html#a9e977d696050956210c61b20604fcfbe", null ]
];