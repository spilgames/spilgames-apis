var classcom_1_1spilgames_1_1framework_1_1ui_1_1_spil_activity =
[
    [ "onCreate", "classcom_1_1spilgames_1_1framework_1_1ui_1_1_spil_activity.html#a46be5e6d315f0df3141e9d351cad673b", null ],
    [ "onStart", "classcom_1_1spilgames_1_1framework_1_1ui_1_1_spil_activity.html#aa8aa6c91db32e4399d9896dc56b9ad6f", null ],
    [ "onStop", "classcom_1_1spilgames_1_1framework_1_1ui_1_1_spil_activity.html#ae7e52f9148675054b762e2afd2ba8e89", null ]
];