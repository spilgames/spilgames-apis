var interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener =
[
    [ "adMoreGamesDidAppear", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#aa47994ba67ead7b512847def87787246", null ],
    [ "adMoreGamesDidDismiss", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#a327955346dc18299c9dd967647982390", null ],
    [ "adMoreGamesDidFailToAppear", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#ad9aa14ccb2537c3de76066ebedba418a", null ],
    [ "adMoreGamesWillAppear", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#abb68b042ac4df917b049d1c3f0cddc7b", null ],
    [ "onAdsFailedToLoad", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#a885145e7e91a52250dc5f59670de9491", null ],
    [ "onAdsLoaded", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#a9f16bdb7304700415f87801df495d5ee", null ]
];