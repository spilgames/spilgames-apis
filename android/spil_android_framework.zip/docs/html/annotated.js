var annotated =
[
    [ "com", null, [
      [ "spilgames", null, [
        [ "framework", null, [
          [ "environment", null, [
            [ "DevAdsOrientation", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_ads_orientation.html", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_ads_orientation" ],
            [ "DevEnvironment", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_environment.html", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_environment" ],
            [ "DevStores", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores.html", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores" ],
            [ "InGameAdView", "classcom_1_1spilgames_1_1framework_1_1environment_1_1_in_game_ad_view.html", "classcom_1_1spilgames_1_1framework_1_1environment_1_1_in_game_ad_view" ]
          ] ],
          [ "listeners", null, [
            [ "AdsListener", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener" ],
            [ "AppSettingsListener", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener.html", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener" ],
            [ "InGameAdListener", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_in_game_ad_listener.html", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_in_game_ad_listener" ],
            [ "SpilListener", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_spil_listener.html", null ]
          ] ],
          [ "SpilInterface", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface" ]
        ] ]
      ] ]
    ] ]
];