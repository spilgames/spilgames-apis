var classcom_1_1spilgames_1_1framework_1_1environment_1_1_in_game_ad_view =
[
    [ "InGameAdView", "classcom_1_1spilgames_1_1framework_1_1environment_1_1_in_game_ad_view.html#a18b4ada002a7295e1c49bc4aa082a0e2", null ],
    [ "showAd", "classcom_1_1spilgames_1_1framework_1_1environment_1_1_in_game_ad_view.html#ae5ec5fc4e19bd3dd7506eb317c7b2ffc", null ]
];