var hierarchy =
[
    [ "com.spilgames.framework.environment.DevAdsOrientation", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_ads_orientation.html", null ],
    [ "com.spilgames.framework.environment.DevEnvironment", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_environment.html", null ],
    [ "com.spilgames.framework.environment.DevStores", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores.html", null ],
    [ "com.spilgames.framework.SpilInterface", "interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html", null ],
    [ "com.spilgames.framework.listeners.SpilListener", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_spil_listener.html", [
      [ "com.spilgames.framework.listeners.AdsListener", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html", null ],
      [ "com.spilgames.framework.listeners.AppSettingsListener", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener.html", null ],
      [ "com.spilgames.framework.listeners.InGameAdListener", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_in_game_ad_listener.html", null ]
    ] ],
    [ "FrameLayout", null, [
      [ "com.spilgames.framework.environment.InGameAdView", "classcom_1_1spilgames_1_1framework_1_1environment_1_1_in_game_ad_view.html", null ]
    ] ]
];