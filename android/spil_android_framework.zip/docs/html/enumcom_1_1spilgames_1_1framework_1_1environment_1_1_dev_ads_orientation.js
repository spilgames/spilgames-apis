var enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_ads_orientation =
[
    [ "DevAdsOrientation", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_ads_orientation.html#a008c45a3572a0dd599cfebc5aa29d4f8", null ],
    [ "getValue", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_ads_orientation.html#a4d80403692bc16933d1456954f3b25f7", null ],
    [ "LANDSCAPE", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_ads_orientation.html#a978b5f61d65fedcf40f9717ed1ea60f4", null ],
    [ "PORTRAIT", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_ads_orientation.html#a5d3899ee0fae70f91bcaee9babef3124", null ]
];