var interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener =
[
    [ "onAppSettingsDidFailWithError", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener.html#ad334b4f08522f3873c2b841281da8d3f", null ],
    [ "onAppSettingsDidLoad", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener.html#a876e8f443f0732730457827fde0b769d", null ]
];