var interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_in_game_ad_listener =
[
    [ "onInGameAdError", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_in_game_ad_listener.html#af98201c44a20ac2b2c0e626fb334a6d8", null ],
    [ "onInGameAdRetrieved", "interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_in_game_ad_listener.html#ad63a7d7dfa79759bbae0e409e240eb33", null ]
];