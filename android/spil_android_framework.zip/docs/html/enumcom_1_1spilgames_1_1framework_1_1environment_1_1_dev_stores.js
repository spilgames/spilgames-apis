var enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores =
[
    [ "DevStores", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores.html#a984d74519e1b13c4e4a574ad1ee745a0", null ],
    [ "getId", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores.html#acc91a05240711bf4ac816d3e628d26e7", null ],
    [ "getValue", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores.html#a79b95dc044b1ec5479801074d5505bd4", null ],
    [ "SG_STORE_AMAZON", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores.html#a9614dc82e06dfc40304a5b53aafa1cf6", null ],
    [ "SG_STORE_GOOGLE_PLAY", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores.html#a04c6d5f38ec497cdfb6161db26a444d5", null ],
    [ "SG_STORE_IOS", "enumcom_1_1spilgames_1_1framework_1_1environment_1_1_dev_stores.html#a79d39e7cc1e7dd9fd57220b52e90eff0", null ]
];