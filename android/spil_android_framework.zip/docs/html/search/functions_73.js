var searchData=
[
  ['setadslistener',['setAdsListener',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a10c6759ad1a64350f5e33e4f15e1e032',1,'com::spilgames::framework::SpilInterface']]],
  ['setingameadslistener',['setInGameAdsListener',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a0dc6bbd18f01ce094fe997bc3235dbd4',1,'com::spilgames::framework::SpilInterface']]],
  ['setsettingslistener',['setSettingsListener',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#aaa65773843de198bf7e187847348b414',1,'com::spilgames::framework::SpilInterface']]],
  ['showinterstitial',['showInterstitial',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a71fc6657a71133af726ee9e4d625c456',1,'com.spilgames.framework.SpilInterface.showInterstitial()'],['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#adffa17e52071a27e85a85e65aae828e1',1,'com.spilgames.framework.SpilInterface.showInterstitial(String location)']]],
  ['showmoregames',['showMoreGames',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#ad56f1def1d5a6872988fc86a130ccfc9',1,'com::spilgames::framework::SpilInterface']]]
];
