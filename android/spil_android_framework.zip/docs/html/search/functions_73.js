var searchData=
[
  ['setadslistener',['setAdsListener',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a83f579e527b1f602beec70c2cab70afb',1,'com::spilgames::framework::SpilInterface']]],
  ['setingameadslistener',['setInGameAdsListener',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a949720d947d627451afd5c877d825c73',1,'com::spilgames::framework::SpilInterface']]],
  ['setsettingslistener',['setSettingsListener',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#aa2e2a62e578083a0e551c738b1667ad0',1,'com::spilgames::framework::SpilInterface']]],
  ['showinterstitial',['showInterstitial',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a71fc6657a71133af726ee9e4d625c456',1,'com.spilgames.framework.SpilInterface.showInterstitial()'],['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#adffa17e52071a27e85a85e65aae828e1',1,'com.spilgames.framework.SpilInterface.showInterstitial(String location)']]],
  ['showmoregames',['showMoreGames',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#ad56f1def1d5a6872988fc86a130ccfc9',1,'com::spilgames::framework::SpilInterface']]]
];
