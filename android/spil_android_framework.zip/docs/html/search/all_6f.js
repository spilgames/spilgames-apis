var searchData=
[
  ['onadsfailedtoload',['onAdsFailedToLoad',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#a885145e7e91a52250dc5f59670de9491',1,'com::spilgames::framework::listeners::AdsListener']]],
  ['onadsloaded',['onAdsLoaded',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#a9f16bdb7304700415f87801df495d5ee',1,'com::spilgames::framework::listeners::AdsListener']]],
  ['onappsettingsdidfailwitherror',['onAppSettingsDidFailWithError',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener.html#ad334b4f08522f3873c2b841281da8d3f',1,'com::spilgames::framework::listeners::AppSettingsListener']]],
  ['onappsettingsdidload',['onAppSettingsDidLoad',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener.html#a876e8f443f0732730457827fde0b769d',1,'com::spilgames::framework::listeners::AppSettingsListener']]],
  ['oningameaderror',['onInGameAdError',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_in_game_ad_listener.html#af98201c44a20ac2b2c0e626fb334a6d8',1,'com::spilgames::framework::listeners::InGameAdListener']]],
  ['oningameadretrieved',['onInGameAdRetrieved',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_in_game_ad_listener.html#ad63a7d7dfa79759bbae0e409e240eb33',1,'com::spilgames::framework::listeners::InGameAdListener']]]
];
