var searchData=
[
  ['ingameadlistener',['InGameAdListener',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_in_game_ad_listener.html',1,'com::spilgames::framework::listeners']]],
  ['ingameadview',['InGameAdView',['../classcom_1_1spilgames_1_1framework_1_1environment_1_1_in_game_ad_view.html',1,'com::spilgames::framework::environment']]]
];
