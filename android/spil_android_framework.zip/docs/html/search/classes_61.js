var searchData=
[
  ['adslistener',['AdsListener',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html',1,'com::spilgames::framework::listeners']]],
  ['appsettingslistener',['AppSettingsListener',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener.html',1,'com::spilgames::framework::listeners']]]
];
