var searchData=
[
  ['requestingamead',['requestInGameAd',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#af560ac139e3a79d1fff8ddb1496631ec',1,'com.spilgames.framework.SpilInterface.requestInGameAd(String orientation)'],['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html#a20fb6c31eda33f5628ac9916134bc524',1,'com.spilgames.framework.SpilInterface.requestInGameAd(String orientation, String location)']]]
];
