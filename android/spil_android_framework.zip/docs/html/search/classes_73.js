var searchData=
[
  ['spilinterface',['SpilInterface',['../interfacecom_1_1spilgames_1_1framework_1_1_spil_interface.html',1,'com::spilgames::framework']]],
  ['spillistener',['SpilListener',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_spil_listener.html',1,'com::spilgames::framework::listeners']]]
];
