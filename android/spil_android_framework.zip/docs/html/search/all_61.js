var searchData=
[
  ['adinterstitialfailed',['adInterstitialFailed',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#a5d6f6359745d7987c569708f47a1a3f8',1,'com::spilgames::framework::listeners::AdsListener']]],
  ['adinterstitialisshown',['adInterstitialIsShown',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#ad50b1825dafe39045b9cc89a1da9f04b',1,'com::spilgames::framework::listeners::AdsListener']]],
  ['admoregamesdidappear',['adMoreGamesDidAppear',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#aa47994ba67ead7b512847def87787246',1,'com::spilgames::framework::listeners::AdsListener']]],
  ['admoregamesdiddismiss',['adMoreGamesDidDismiss',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#a327955346dc18299c9dd967647982390',1,'com::spilgames::framework::listeners::AdsListener']]],
  ['admoregamesdidfailtoappear',['adMoreGamesDidFailToAppear',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#ad9aa14ccb2537c3de76066ebedba418a',1,'com::spilgames::framework::listeners::AdsListener']]],
  ['admoregameswillappear',['adMoreGamesWillAppear',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html#abb68b042ac4df917b049d1c3f0cddc7b',1,'com::spilgames::framework::listeners::AdsListener']]],
  ['adslistener',['AdsListener',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_ads_listener.html',1,'com::spilgames::framework::listeners']]],
  ['appsettingslistener',['AppSettingsListener',['../interfacecom_1_1spilgames_1_1framework_1_1listeners_1_1_app_settings_listener.html',1,'com::spilgames::framework::listeners']]]
];
