var searchData=
[
  ['sg_5fapp_5fsettings_5fpoll_5ftime_5fkey',['SG_APP_SETTINGS_POLL_TIME_KEY',['../struct_spil_1_1_spil_settings.html#a0b97a4f2ad02116d99e6ca290c4bcfee',1,'Spil::SpilSettings']]],
  ['sg_5fenvironment_5fkey',['SG_ENVIRONMENT_KEY',['../struct_spil_1_1_spil_settings.html#afe5142f2c3b7190de6408148e6ed7566',1,'Spil::SpilSettings']]],
  ['sg_5fenvironment_5fsettings_5furl_5fget',['SG_ENVIRONMENT_SETTINGS_URL_GET',['../struct_spil_1_1_spil_settings.html#a5ec943d70fbe35b5804cf191a9cf77d4',1,'Spil::SpilSettings']]],
  ['sg_5ftracking_5fid_5fkey',['SG_TRACKING_ID_KEY',['../struct_spil_1_1_spil_settings.html#a4585567f358bb7a4818bf72b7a2a26bb',1,'Spil::SpilSettings']]],
  ['sghelpers',['SGHelpers',['../class_spil_1_1_s_g_helpers.html',1,'Spil']]],
  ['spil',['Spil',['../namespace_spil.html',1,'']]],
  ['spilabtestlistener',['SpilABTestListener',['../interface_spil_1_1_spil_a_b_test_listener.html',1,'Spil']]],
  ['spiladslistener',['SpilAdsListener',['../interface_spil_1_1_spil_ads_listener.html',1,'Spil']]],
  ['spilappsettingslistener',['SpilAppSettingsListener',['../interface_spil_1_1_spil_app_settings_listener.html',1,'Spil']]],
  ['spilsettings',['SpilSettings',['../struct_spil_1_1_spil_settings.html',1,'Spil']]],
  ['spiltrackingextendedlistener',['SpilTrackingExtendedListener',['../interface_spil_1_1_spil_tracking_extended_listener.html',1,'Spil']]],
  ['spilunity',['SpilUnity',['../class_spil_unity.html',1,'']]],
  ['startads',['StartAds',['../class_spil_unity.html#a90e7f5daf25b9ab20156ec87b34a4b03',1,'SpilUnity']]],
  ['store',['store',['../namespace_spil.html#ac1235df14db564ddaa2a72cbf2ca1832',1,'Spil']]]
];
