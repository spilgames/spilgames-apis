var namespaces =
[
    [ "Spil", "namespace_spil.html", null ]
];