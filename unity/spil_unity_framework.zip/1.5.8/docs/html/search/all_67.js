var searchData=
[
  ['getabtest',['GetABTest',['../class_spil_unity.html#a662f5d7dcc9d9341baf38d9ed42581a3',1,'SpilUnity']]],
  ['getappname',['GetAppName',['../class_spil_1_1_s_g_helpers.html#a226b8c1a72f613be0faffcfababf5668',1,'Spil::SGHelpers']]],
  ['getappversion',['GetAppVersion',['../class_spil_1_1_s_g_helpers.html#a505d7992663e61137a60d2996f5509bd',1,'Spil::SGHelpers']]],
  ['getsettings',['GetSettings',['../class_spil_unity.html#a5cf96e4b6475cb65639c7401d67042bb',1,'SpilUnity']]],
  ['gettrackextended',['GetTrackExtended',['../class_spil_unity.html#a65c02eb6987761e9b143ea5b6cbe57fc',1,'SpilUnity']]],
  ['getudid',['GetUDID',['../class_spil_1_1_s_g_helpers.html#a74c2c11d807c62a1e4f638821d9b2837',1,'Spil::SGHelpers']]]
];
