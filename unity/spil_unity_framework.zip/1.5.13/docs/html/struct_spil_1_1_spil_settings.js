var struct_spil_1_1_spil_settings =
[
    [ "SG_APP_SETTINGS_POLL_TIME_KEY", "struct_spil_1_1_spil_settings.html#a0b97a4f2ad02116d99e6ca290c4bcfee", null ],
    [ "SG_ENVIRONMENT_KEY", "struct_spil_1_1_spil_settings.html#a51a29766f46466e512067bc8935d70fa", null ],
    [ "SG_ENVIRONMENT_SETTINGS_URL_GET", "struct_spil_1_1_spil_settings.html#a5ec943d70fbe35b5804cf191a9cf77d4", null ],
    [ "SG_STORE_ID", "struct_spil_1_1_spil_settings.html#addf69324fd87fe6fd405cb8dcfbe4d6e", null ],
    [ "SG_TRACKING_ID_KEY", "struct_spil_1_1_spil_settings.html#a4585567f358bb7a4818bf72b7a2a26bb", null ]
];