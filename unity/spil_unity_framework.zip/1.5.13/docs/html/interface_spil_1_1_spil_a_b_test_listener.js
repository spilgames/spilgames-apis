var interface_spil_1_1_spil_a_b_test_listener =
[
    [ "ABTestSessionDidEnd", "interface_spil_1_1_spil_a_b_test_listener.html#a81949347b232bc8a02a83b8f97bb9543", null ],
    [ "ABTestSessionDidStart", "interface_spil_1_1_spil_a_b_test_listener.html#a7fb3c8fb0f35b9498251b56636c0be3f", null ],
    [ "ABTestSessionDiffReceived", "interface_spil_1_1_spil_a_b_test_listener.html#aa1946c7d920c20c2dff4f0a6bfb6482e", null ]
];