var searchData=
[
  ['adsdata',['AdsData',['../class_spil_unity_1_1_ads_data.html',1,'SpilUnity']]]
];
