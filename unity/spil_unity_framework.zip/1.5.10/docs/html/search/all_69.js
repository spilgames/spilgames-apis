var searchData=
[
  ['initialize',['Initialize',['../class_spil_unity.html#afbf4d6f4c13a80184e85c4db448a0b6c',1,'SpilUnity']]]
];
