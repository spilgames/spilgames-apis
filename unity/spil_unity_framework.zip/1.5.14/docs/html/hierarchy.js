var hierarchy =
[
    [ "SpilUnity.AdsData", "class_spil_unity_1_1_ads_data.html", null ],
    [ "MonoBehaviour", null, [
      [ "Spil.IgaPanel", "class_spil_1_1_iga_panel.html", null ],
      [ "SpilUnity", "class_spil_unity.html", null ]
    ] ],
    [ "Spil.SGHelpers", "class_spil_1_1_s_g_helpers.html", null ],
    [ "Spil.SpilABTestListener", "interface_spil_1_1_spil_a_b_test_listener.html", null ],
    [ "Spil.SpilAdsListener", "interface_spil_1_1_spil_ads_listener.html", null ],
    [ "Spil.SpilAppSettingsListener", "interface_spil_1_1_spil_app_settings_listener.html", null ],
    [ "Spil.SpilInGameAdsListener", "interface_spil_1_1_spil_in_game_ads_listener.html", null ],
    [ "Spil.SpilSettings", "struct_spil_1_1_spil_settings.html", null ]
];