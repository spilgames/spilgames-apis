var interface_spil_1_1_spil_in_game_ads_listener =
[
    [ "AdDidFailIngameAsset", "interface_spil_1_1_spil_in_game_ads_listener.html#aa906525454fda1b7ce96d08ed917e7e1", null ],
    [ "AdDidLoadIngameAsset", "interface_spil_1_1_spil_in_game_ads_listener.html#a08413c788b914b7fd71fdf1e78e70053", null ]
];