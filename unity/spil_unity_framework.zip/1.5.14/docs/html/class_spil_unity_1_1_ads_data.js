var class_spil_unity_1_1_ads_data =
[
    [ "adId", "class_spil_unity_1_1_ads_data.html#a0d12c09652ae7288e6c87d776c2fc26e", null ],
    [ "link", "class_spil_unity_1_1_ads_data.html#a64e6c0d3623a6d518a7ed3920c0d777c", null ],
    [ "name", "class_spil_unity_1_1_ads_data.html#a3a6f03e121e24a9ca27dd45190277f58", null ],
    [ "url", "class_spil_unity_1_1_ads_data.html#afa2d5b6d2e24117740ee6715c9edc49f", null ]
];