var interface_spil_1_1_spil_app_settings_listener =
[
    [ "AppSettingsDidFailWithError", "interface_spil_1_1_spil_app_settings_listener.html#a522655bcca3e0021d136aeff20f1ca0b", null ],
    [ "AppSettingsDidLoad", "interface_spil_1_1_spil_app_settings_listener.html#ad9e98b0d7f4c645b60c7f9bb9e6af9fb", null ],
    [ "AppSettingsDidStartDownload", "interface_spil_1_1_spil_app_settings_listener.html#a4f17bf5c6686a2adc88ba77a8eea9859", null ]
];