var interface_spil_1_1_spil_ads_listener =
[
    [ "AdDidAppear", "interface_spil_1_1_spil_ads_listener.html#aa8d6f816321b2b5faa6c3d99c0c63a19", null ],
    [ "AdDidFailToAppear", "interface_spil_1_1_spil_ads_listener.html#a542479228204984ab606d17a211ea62d", null ],
    [ "AdDidFailToStart", "interface_spil_1_1_spil_ads_listener.html#a89d0efa793e1f8825b15ba18cdcfe20a", null ],
    [ "AdDidStart", "interface_spil_1_1_spil_ads_listener.html#a77aaadfa2713a16d3c1c46beda8968a9", null ],
    [ "AdMoreGamesDidAppear", "interface_spil_1_1_spil_ads_listener.html#a6cb646a5253675f778814668e27a39f2", null ],
    [ "AdMoreGamesDidDismiss", "interface_spil_1_1_spil_ads_listener.html#a2a25aad216db95ea522096d88bc8375e", null ],
    [ "AdMoreGamesDidFailToAppear", "interface_spil_1_1_spil_ads_listener.html#a5e9fb08623dd53069fa2b85b80d2a502", null ],
    [ "AdMoreGamesWillAppear", "interface_spil_1_1_spil_ads_listener.html#a3a843c5377b606a1dc7a1f1e2a4bf50e", null ],
    [ "AdPopupDidDismiss", "interface_spil_1_1_spil_ads_listener.html#adf06a4aff1c987c48e450f4b4ef60d4e", null ],
    [ "AdWillAppear", "interface_spil_1_1_spil_ads_listener.html#ac2460f8e95784724e4848e751d374677", null ]
];