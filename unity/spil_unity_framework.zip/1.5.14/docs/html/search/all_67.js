var searchData=
[
  ['getappname',['GetAppName',['../class_spil_1_1_s_g_helpers.html#a226b8c1a72f613be0faffcfababf5668',1,'Spil::SGHelpers']]],
  ['getappversion',['GetAppVersion',['../class_spil_1_1_s_g_helpers.html#a505d7992663e61137a60d2996f5509bd',1,'Spil::SGHelpers']]],
  ['getudid',['GetUDID',['../class_spil_1_1_s_g_helpers.html#a74c2c11d807c62a1e4f638821d9b2837',1,'Spil::SGHelpers']]]
];
