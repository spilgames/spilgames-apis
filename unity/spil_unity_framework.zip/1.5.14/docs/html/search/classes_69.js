var searchData=
[
  ['igapanel',['IgaPanel',['../class_spil_1_1_iga_panel.html',1,'Spil']]]
];
