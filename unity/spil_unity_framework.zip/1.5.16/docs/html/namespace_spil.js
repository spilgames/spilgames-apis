var namespace_spil =
[
    [ "IgaPanel", "class_spil_1_1_iga_panel.html", "class_spil_1_1_iga_panel" ],
    [ "SGHelpers", "class_spil_1_1_s_g_helpers.html", null ],
    [ "SpilABTestListener", "interface_spil_1_1_spil_a_b_test_listener.html", "interface_spil_1_1_spil_a_b_test_listener" ],
    [ "SpilAdsListener", "interface_spil_1_1_spil_ads_listener.html", "interface_spil_1_1_spil_ads_listener" ],
    [ "SpilAppSettingsListener", "interface_spil_1_1_spil_app_settings_listener.html", "interface_spil_1_1_spil_app_settings_listener" ],
    [ "SpilInGameAdsListener", "interface_spil_1_1_spil_in_game_ads_listener.html", "interface_spil_1_1_spil_in_game_ads_listener" ],
    [ "SpilSettings", "struct_spil_1_1_spil_settings.html", "struct_spil_1_1_spil_settings" ]
];