var searchData=
[
  ['igapanel',['IgaPanel',['../class_spil_1_1_iga_panel.html',1,'Spil']]],
  ['initialize',['Initialize',['../class_spil_unity.html#afbf4d6f4c13a80184e85c4db448a0b6c',1,'SpilUnity']]],
  ['instance',['Instance',['../class_spil_unity.html#a9c1c6bdbbb2f8123306e159ba67f6007',1,'SpilUnity']]]
];
