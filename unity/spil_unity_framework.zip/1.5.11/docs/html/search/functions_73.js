var searchData=
[
  ['setabtestlistener',['SetABTestListener',['../class_spil_unity.html#aa19aadb60034dbb39d0a405606df2f68',1,'SpilUnity']]],
  ['setadslistener',['SetAdsListener',['../class_spil_unity.html#a567fee7ab5b8ac0be08717e9c1943124',1,'SpilUnity']]],
  ['setappsettingslistener',['SetAppSettingsListener',['../class_spil_unity.html#a80932bdfa5eb18749d7557bb5a97140e',1,'SpilUnity']]],
  ['setextendedtrackinglistener',['SetExtendedTrackingListener',['../class_spil_unity.html#a3fa8624b845a35e6c7de14d5ec0b7805',1,'SpilUnity']]],
  ['setingameadlistener',['SetInGameAdListener',['../class_spil_unity.html#a3be45636bee2526da3597a38918ad06c',1,'SpilUnity']]],
  ['startads',['StartAds',['../class_spil_unity.html#a90e7f5daf25b9ab20156ec87b34a4b03',1,'SpilUnity']]]
];
