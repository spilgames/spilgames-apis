var searchData=
[
  ['showmoregames',['ShowMoreGames',['../class_spil_unity.html#aafcb9ee9a60fb46242dd2d03c39362f0',1,'SpilUnity']]],
  ['shownextad',['ShowNextAd',['../class_spil_unity.html#a944b63d1feb17470eba3ee48ca2c9e7f',1,'SpilUnity']]],
  ['startads',['StartAds',['../class_spil_unity.html#a90e7f5daf25b9ab20156ec87b34a4b03',1,'SpilUnity']]]
];
