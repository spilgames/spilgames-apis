var struct_spil_1_1_spil_settings =
[
    [ "SG_APP_SETTINGS_POLL_TIME_KEY", "struct_spil_1_1_spil_settings.html#a0b97a4f2ad02116d99e6ca290c4bcfee", null ],
    [ "SG_ENVIRONMENT_KEY", "struct_spil_1_1_spil_settings.html#afe5142f2c3b7190de6408148e6ed7566", null ],
    [ "SG_ENVIRONMENT_SETTINGS_URL_GET", "struct_spil_1_1_spil_settings.html#a5ec943d70fbe35b5804cf191a9cf77d4", null ],
    [ "SG_TRACKING_ID_KEY", "struct_spil_1_1_spil_settings.html#a4585567f358bb7a4818bf72b7a2a26bb", null ]
];