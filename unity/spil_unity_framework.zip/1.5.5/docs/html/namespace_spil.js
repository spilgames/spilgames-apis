var namespace_spil =
[
    [ "SGHelpers", "class_spil_1_1_s_g_helpers.html", "class_spil_1_1_s_g_helpers" ],
    [ "SpilSettings", "struct_spil_1_1_spil_settings.html", "struct_spil_1_1_spil_settings" ],
    [ "SpilAppSettingsListener", "interface_spil_1_1_spil_app_settings_listener.html", "interface_spil_1_1_spil_app_settings_listener" ],
    [ "SpilAdsListener", "interface_spil_1_1_spil_ads_listener.html", "interface_spil_1_1_spil_ads_listener" ],
    [ "SpilABTestListener", "interface_spil_1_1_spil_a_b_test_listener.html", "interface_spil_1_1_spil_a_b_test_listener" ],
    [ "SpilTrackingExtendedListener", "interface_spil_1_1_spil_tracking_extended_listener.html", "interface_spil_1_1_spil_tracking_extended_listener" ]
];