var class_spil_android =
[
    [ "SpilAndroid", "class_spil_android.html#aa48e155efac386b5282c92036d8ad7b7", null ],
    [ "StartTracking", "class_spil_android.html#ac056991c35ba40a6564fee4fa4bbce51", null ],
    [ "StopTracking", "class_spil_android.html#ae9532615df9de0094f831dfa1483d72f", null ],
    [ "TrackEndTimedEvent", "class_spil_android.html#a95b3ca8d822aa35a8437366f852452b1", null ],
    [ "TrackEndTimedEvent", "class_spil_android.html#a9cba5861b6f1b0da424d1f92681c8bd6", null ],
    [ "TrackError", "class_spil_android.html#aaff969d98fb7ad65db9fb50c609f25c2", null ],
    [ "TrackEvent", "class_spil_android.html#a477c98bb60688530c663a609aed999b8", null ],
    [ "TrackEvent", "class_spil_android.html#adbd90dc7df59383ba76176918bbe8407", null ],
    [ "TrackEvent", "class_spil_android.html#a0c60b4d48b8f0ea5e2b49356c187031a", null ],
    [ "TrackEvent", "class_spil_android.html#abd9c96462050b25b23f3cfd68055eb57", null ],
    [ "TrackPage", "class_spil_android.html#ad31edec67824a31c7b5a4227a3d2a4f3", null ],
    [ "TrackTimedEvent", "class_spil_android.html#a334b748a3bb64101fa1fa0f049178131", null ],
    [ "TrackUserId", "class_spil_android.html#a3008250f3c0a42ec5fc5a84bf188b15a", null ],
    [ "instance", "class_spil_android.html#a0912d31713676dc7278dedd8606e897d", null ]
];