var searchData=
[
  ['sg_5fapp_5fsettings_5fpoll_5ftime_5fkey',['SG_APP_SETTINGS_POLL_TIME_KEY',['../struct_spil_1_1_spil_settings.html#a0b97a4f2ad02116d99e6ca290c4bcfee',1,'Spil::SpilSettings']]],
  ['sg_5fenvironment_5fkey',['SG_ENVIRONMENT_KEY',['../struct_spil_1_1_spil_settings.html#afe5142f2c3b7190de6408148e6ed7566',1,'Spil::SpilSettings']]],
  ['sg_5fenvironment_5fsettings_5furl_5fget',['SG_ENVIRONMENT_SETTINGS_URL_GET',['../struct_spil_1_1_spil_settings.html#a5ec943d70fbe35b5804cf191a9cf77d4',1,'Spil::SpilSettings']]],
  ['sg_5ftracking_5fid_5fkey',['SG_TRACKING_ID_KEY',['../struct_spil_1_1_spil_settings.html#a4585567f358bb7a4818bf72b7a2a26bb',1,'Spil::SpilSettings']]]
];
