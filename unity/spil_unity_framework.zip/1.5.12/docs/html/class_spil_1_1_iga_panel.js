var class_spil_1_1_iga_panel =
[
    [ "adId", "class_spil_1_1_iga_panel.html#afbfb3f44683dbca050118f91f5112939", null ],
    [ "link", "class_spil_1_1_iga_panel.html#a13c76b40e23e096448e673f869220318", null ],
    [ "spilUnity", "class_spil_1_1_iga_panel.html#aa744f71aa7ca6d6bcc0389a7636e8b40", null ],
    [ "texture", "class_spil_1_1_iga_panel.html#a3f95a0932dc83ff0023656286b088c05", null ]
];