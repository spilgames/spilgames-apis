var interface_a_b_test_adapter =
[
    [ "endSession", "interface_a_b_test_adapter.html#aa00bdd5304f029d01e5fbe9c5061d03b", null ],
    [ "event:withParams:", "interface_a_b_test_adapter.html#aa99569cc1edc864894c05e0dc2c819b1", null ],
    [ "getUserDiffs:delegate:", "interface_a_b_test_adapter.html#a369def77adff72d985659c4cadf3f315", null ],
    [ "initWithSettings:", "interface_a_b_test_adapter.html#a8854093122267990a7f58b54f5469326", null ],
    [ "saveQueue", "interface_a_b_test_adapter.html#a8e5966b95b9457dce43890c66dd27976", null ],
    [ "sendQueue:", "interface_a_b_test_adapter.html#a6b76a7ba2eff27aa2b133feac4c1da07", null ],
    [ "startSession", "interface_a_b_test_adapter.html#ae9d4ee22fe5b4215829e6ff18e8b69f9", null ],
    [ "userUpdate:", "interface_a_b_test_adapter.html#a2a66c142154fe3309676ea4c4016a167", null ]
];