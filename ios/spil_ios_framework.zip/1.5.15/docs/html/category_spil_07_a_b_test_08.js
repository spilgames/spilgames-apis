var category_spil_07_a_b_test_08 =
[
    [ "abtestGetTestDiff", "category_spil_07_a_b_test_08.html#add2f64f209c81376be64cc50e230189d", null ],
    [ "abtestGetTestDiffForUser:", "category_spil_07_a_b_test_08.html#ab6d148638eaafa14028f86d402bad5cc", null ],
    [ "abtestMarkSucceedTest:withParameters:", "category_spil_07_a_b_test_08.html#a09cfb7794a5734d433b16babc53d3979", null ],
    [ "abtestUpdateUserInfo", "category_spil_07_a_b_test_08.html#a2bdb301d557d73f57ac0a8fd9ae5ef58", null ],
    [ "abtestUpdateUserInfoWith:", "category_spil_07_a_b_test_08.html#a7072161e08c8f415a820070e282e75e4", null ],
    [ "setABTestDelegate:", "category_spil_07_a_b_test_08.html#afa7e9cf5bf7c9d8e0edf000a06a87e79", null ]
];