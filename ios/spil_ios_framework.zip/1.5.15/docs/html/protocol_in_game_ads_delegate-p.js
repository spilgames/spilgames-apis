var protocol_in_game_ads_delegate_p =
[
    [ "adDidFailToGetInGameAd:", "protocol_in_game_ads_delegate-p.html#afe511109399847f5ac9ccf4ea16f67aa", null ],
    [ "adDidGetInGameAd:", "protocol_in_game_ads_delegate-p.html#a6b0f05a54ea32abcb51dfb01ba65ecd9", null ]
];