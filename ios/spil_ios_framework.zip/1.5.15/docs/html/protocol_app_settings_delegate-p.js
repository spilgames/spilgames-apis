var protocol_app_settings_delegate_p =
[
    [ "appSettingsDidFailWithError:", "protocol_app_settings_delegate-p.html#a1bf31e9b88f4bc2d86c67d42bd55e694", null ],
    [ "appSettingsDidLoad:", "protocol_app_settings_delegate-p.html#a43611eb1d8e67e0d9ff6b5218c85bb46", null ],
    [ "appSettingsDidStartDownload", "protocol_app_settings_delegate-p.html#a2d6b14da270348615580005a380d1523", null ]
];