var annotated =
[
    [ "<AppSettingsDelegate>", "protocol_app_settings_delegate-p.html", "protocol_app_settings_delegate-p" ],
    [ "<InGameAdsDelegate>", "protocol_in_game_ads_delegate-p.html", "protocol_in_game_ads_delegate-p" ]
];