var searchData=
[
  ['appsettingsdelegate_2dp',['AppSettingsDelegate-p',['../protocol_app_settings_delegate-p.html',1,'']]]
];
