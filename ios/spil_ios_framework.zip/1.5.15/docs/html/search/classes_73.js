var searchData=
[
  ['spil_28abtest_29',['Spil(ABTest)',['../category_spil_07_a_b_test_08.html',1,'']]],
  ['spil_28ads_29',['Spil(Ads)',['../category_spil_07_ads_08.html',1,'']]],
  ['spil_28appsettings_29',['Spil(AppSettings)',['../category_spil_07_app_settings_08.html',1,'']]],
  ['spil_28tracking_29',['Spil(Tracking)',['../category_spil_07_tracking_08.html',1,'']]]
];
