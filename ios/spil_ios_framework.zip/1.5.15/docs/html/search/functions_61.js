var searchData=
[
  ['addidfailtogetingamead_3a',['adDidFailToGetInGameAd:',['../protocol_in_game_ads_delegate-p.html#afe511109399847f5ac9ccf4ea16f67aa',1,'InGameAdsDelegate-p']]],
  ['addidgetingamead_3a',['adDidGetInGameAd:',['../protocol_in_game_ads_delegate-p.html#a6b0f05a54ea32abcb51dfb01ba65ecd9',1,'InGameAdsDelegate-p']]],
  ['appsettingsdidfailwitherror_3a',['appSettingsDidFailWithError:',['../protocol_app_settings_delegate-p.html#a1bf31e9b88f4bc2d86c67d42bd55e694',1,'AppSettingsDelegate-p']]],
  ['appsettingsdidload_3a',['appSettingsDidLoad:',['../protocol_app_settings_delegate-p.html#a43611eb1d8e67e0d9ff6b5218c85bb46',1,'AppSettingsDelegate-p']]],
  ['appsettingsdidstartdownload',['appSettingsDidStartDownload',['../protocol_app_settings_delegate-p.html#a2d6b14da270348615580005a380d1523',1,'AppSettingsDelegate-p']]]
];
