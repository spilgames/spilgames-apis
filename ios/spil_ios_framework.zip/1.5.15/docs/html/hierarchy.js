var hierarchy =
[
    [ "<AppSettingsDelegate>", "protocol_app_settings_delegate-p.html", null ],
    [ "<NSObject>", null, [
      [ "<InGameAdsDelegate>", "protocol_in_game_ads_delegate-p.html", null ]
    ] ]
];