var searchData=
[
  ['setabtestdelegate_3a',['setABTestDelegate:',['../interface_spil.html#acaad13fc37bbcaf9a449dae2636baf75',1,'Spil']]],
  ['setadsdelegate_3a',['setAdsDelegate:',['../interface_spil.html#a1f38883f8a436d30d182198ac207796b',1,'Spil']]],
  ['setappsettingsdelegate_3a',['setAppSettingsDelegate:',['../interface_spil.html#a8fb854c3c072d6fbe0f03e9838fc4226',1,'Spil']]],
  ['setextendedtrackingdelegate_3a',['setExtendedTrackingDelegate:',['../interface_spil.html#a190dac29dcf56d721653757a59a13b7d',1,'Spil']]],
  ['setingameadsdelegate_3a',['setInGameAdsDelegate:',['../interface_spil.html#a2aac087184a9abdce296b77fd9aa0764',1,'Spil']]],
  ['sharedinstance',['sharedInstance',['../interface_spil.html#aa627e083940cc0eab9a4b5a419a1b822',1,'Spil']]],
  ['spil',['Spil',['../interface_spil.html',1,'']]],
  ['spilhelpers',['SpilHelpers',['../interface_spil_helpers.html',1,'']]],
  ['spilwithappid_3atoken_3aconfigs_3a',['spilWithAppID:token:configs:',['../interface_spil.html#afa634e419324a6823bd49f5b013e0cf9',1,'Spil']]]
];
