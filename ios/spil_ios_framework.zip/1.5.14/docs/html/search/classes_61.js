var searchData=
[
  ['abtestadapter',['ABTestAdapter',['../interface_a_b_test_adapter.html',1,'']]],
  ['abtestdelegate_2dp',['ABTestDelegate-p',['../protocol_a_b_test_delegate-p.html',1,'']]],
  ['adsdelegate_2dp',['AdsDelegate-p',['../protocol_ads_delegate-p.html',1,'']]],
  ['appsettingsdelegate_2dp',['AppSettingsDelegate-p',['../protocol_app_settings_delegate-p.html',1,'']]]
];
