var interface_in_game_ads_button =
[
    [ "openBrowser:", "interface_in_game_ads_button.html#a7dc93bb50afe278584d4ad48d738f84f", null ],
    [ "url", "interface_in_game_ads_button.html#aceb8c342abb37069ae445add75b4c81a", null ]
];