var searchData=
[
  ['enableads_3a',['enableAds:',['../interface_spil.html#a9ee80c0ea3abf812285e5cba853118c2',1,'Spil']]]
];
