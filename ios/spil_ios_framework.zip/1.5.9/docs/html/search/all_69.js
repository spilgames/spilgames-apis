var searchData=
[
  ['ingameads',['InGameAds',['../interface_in_game_ads.html',1,'']]],
  ['ingameadsbutton',['InGameAdsButton',['../interface_in_game_ads_button.html',1,'']]],
  ['initwithcontainer_3aandtracker_3a',['initWithContainer:andTracker:',['../interface_more_games.html#aa18e26a367d9701b92d88ba716bc1e2a',1,'MoreGames']]],
  ['initwithprovider_3aandtracker_3a',['initWithProvider:andTracker:',['../interface_in_game_ads.html#a30f0502431172328220f92ca98f5d99f',1,'InGameAds']]]
];
