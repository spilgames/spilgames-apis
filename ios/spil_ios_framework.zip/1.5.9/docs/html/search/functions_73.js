var searchData=
[
  ['setdelegate_3a',['setDelegate:',['../interface_more_games.html#a95e3e2af39f00c885b91735f344d8789',1,'MoreGames']]],
  ['sharedinstance',['sharedInstance',['../interface_spil.html#aa627e083940cc0eab9a4b5a419a1b822',1,'Spil']]],
  ['showmoregames',['showMoreGames',['../interface_more_games.html#a9c22bf8733b2bba4e25537f2194fd785',1,'MoreGames']]],
  ['spilwithappid_3atoken_3aconfigs_3a',['spilWithAppID:token:configs:',['../interface_spil.html#afa634e419324a6823bd49f5b013e0cf9',1,'Spil']]]
];
