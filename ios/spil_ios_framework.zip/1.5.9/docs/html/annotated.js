var annotated =
[
    [ "<ABTestDelegate>", "protocol_a_b_test_delegate-p.html", "protocol_a_b_test_delegate-p" ],
    [ "<AdsDelegate>", "protocol_ads_delegate-p.html", "protocol_ads_delegate-p" ],
    [ "<AppSettingsDelegate>", "protocol_app_settings_delegate-p.html", "protocol_app_settings_delegate-p" ],
    [ "InGameAds", "interface_in_game_ads.html", "interface_in_game_ads" ],
    [ "InGameAdsButton", "interface_in_game_ads_button.html", "interface_in_game_ads_button" ],
    [ "MoreGames", "interface_more_games.html", "interface_more_games" ],
    [ "Spil", "interface_spil.html", "interface_spil" ],
    [ "SpilHelpers", "interface_spil_helpers.html", "interface_spil_helpers" ],
    [ "<SpilTracker>", "protocol_spil_tracker-p.html", "protocol_spil_tracker-p" ],
    [ "<TrackingExtendedDelegate>", "protocol_tracking_extended_delegate-p.html", "protocol_tracking_extended_delegate-p" ]
];