var annotated =
[
    [ "<ABTestDelegate>", "protocol_a_b_test_delegate-p.html", "protocol_a_b_test_delegate-p" ],
    [ "<AppSettingsDelegate>", "protocol_app_settings_delegate-p.html", "protocol_app_settings_delegate-p" ],
    [ "Spil", "interface_spil.html", "interface_spil" ],
    [ "SpilHelpers", "interface_spil_helpers.html", "interface_spil_helpers" ],
    [ "<SpilTracker>", "protocol_spil_tracker-p.html", "protocol_spil_tracker-p" ],
    [ "<TrackingExtendedDelegate>", "protocol_tracking_extended_delegate-p.html", "protocol_tracking_extended_delegate-p" ]
];