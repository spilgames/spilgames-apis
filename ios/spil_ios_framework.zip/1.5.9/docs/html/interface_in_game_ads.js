var interface_in_game_ads =
[
    [ "initWithProvider:andTracker:", "interface_in_game_ads.html#a30f0502431172328220f92ca98f5d99f", null ],
    [ "placeAdOn:at:", "interface_in_game_ads.html#a591a42f55b662fd9a3de842f8ca87266", null ],
    [ "removePlacedAds", "interface_in_game_ads.html#ab936374d1dfc220a36de6813a4686a32", null ]
];