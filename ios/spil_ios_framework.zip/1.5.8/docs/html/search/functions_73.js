var searchData=
[
  ['sharedinstance',['sharedInstance',['../interface_spil.html#aa627e083940cc0eab9a4b5a419a1b822',1,'Spil']]],
  ['showmoregames',['showMoreGames',['../interface_spil.html#a8fcd36fb57bbf0705b3a25d79056f5af',1,'Spil']]],
  ['shownextad',['showNextAd',['../interface_spil.html#a866a57e8d1e48edfa1ee70b2694bbc21',1,'Spil']]],
  ['spilwithappid_3atoken_3aconfigs_3a',['spilWithAppID:token:configs:',['../interface_spil.html#afa634e419324a6823bd49f5b013e0cf9',1,'Spil']]]
];
