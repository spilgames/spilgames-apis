var protocol_spil_tracker_p =
[
    [ "trackAge:", "protocol_spil_tracker-p.html#a598b10dcee3a67b482aaff59e952658c", null ],
    [ "trackEndTimedEvent:withParams:", "protocol_spil_tracker-p.html#a910ec09b3abae2f78160a6fe5f8450f2", null ],
    [ "trackError:message:exception:", "protocol_spil_tracker-p.html#a29ed732c1ad608080f4a16571e72d39f", null ],
    [ "trackEvent:action:label:value:withParameters:", "protocol_spil_tracker-p.html#a272a839d55856ba65b8c8d677357ad03", null ],
    [ "trackEvent:withParams:", "protocol_spil_tracker-p.html#a7bc300197e672617283248f88ff5838a", null ],
    [ "trackGender:", "protocol_spil_tracker-p.html#a1df38134a12b03cf480cb606c04a648f", null ],
    [ "trackLatitude:longitude:horizontalAccuracy:verticalAccuracy:", "protocol_spil_tracker-p.html#aec3fd4f5d06d4a679b501c123b471c57", null ],
    [ "trackPage:", "protocol_spil_tracker-p.html#a176886f15929ca7215c1d0682157738d", null ],
    [ "trackTimedEvent:", "protocol_spil_tracker-p.html#a8cbeab617506ffb43c42274ae4f2fc6f", null ],
    [ "trackUserID:", "protocol_spil_tracker-p.html#a841ba3e364e4aa4ef47c0cf2bf25720f", null ]
];