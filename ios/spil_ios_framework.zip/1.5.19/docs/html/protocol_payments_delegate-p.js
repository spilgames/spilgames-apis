var protocol_payments_delegate_p =
[
    [ "paymentsDidFailToStart:", "protocol_payments_delegate-p.html#a4f34b13c2e0d46f53038991b033252b5", null ],
    [ "paymentsDidReceiveProductList:", "protocol_payments_delegate-p.html#aa777dc2d011043fca0ac911f18d0a920", null ],
    [ "paymentsDidRestoreProduct:fromTransaction:", "protocol_payments_delegate-p.html#a7c345ce9402d4bfdf0b4d3f8c19012e5", null ],
    [ "paymentsDidStart", "protocol_payments_delegate-p.html#aee086bd8735f7763fa1675b9fdb4e887", null ],
    [ "paymentsTransactionDidFail:", "protocol_payments_delegate-p.html#aaa7f08357ed50b011dbff5411e5fdb87", null ],
    [ "paymentsTransactionDidSucceed:forProduct:", "protocol_payments_delegate-p.html#a6816942ca79d487d93223d020b4dfd22", null ]
];