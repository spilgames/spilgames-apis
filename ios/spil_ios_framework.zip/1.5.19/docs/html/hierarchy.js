var hierarchy =
[
    [ "<AppSettingsDelegate>", "protocol_app_settings_delegate-p.html", null ],
    [ "<NSObject>", null, [
      [ "<InGameAdsDelegate>", "protocol_in_game_ads_delegate-p.html", null ],
      [ "<PaymentsDelegate>", "protocol_payments_delegate-p.html", null ]
    ] ],
    [ "Spil(ABTest)", "category_spil_07_a_b_test_08.html", null ],
    [ "Spil(Ads)", "category_spil_07_ads_08.html", null ],
    [ "Spil(AppSettings)", "category_spil_07_app_settings_08.html", null ],
    [ "Spil(Payments)", "category_spil_07_payments_08.html", null ],
    [ "Spil(Tracking)", "category_spil_07_tracking_08.html", null ]
];