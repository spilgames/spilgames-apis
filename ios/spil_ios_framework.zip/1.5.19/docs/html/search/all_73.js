var searchData=
[
  ['setabtestdelegate_3a',['setABTestDelegate:',['../category_spil_07_a_b_test_08.html#afa7e9cf5bf7c9d8e0edf000a06a87e79',1,'Spil(ABTest)']]],
  ['setadsdelegate_3a',['setAdsDelegate:',['../category_spil_07_ads_08.html#a95416dd0b563d16990628612dc0399a5',1,'Spil(Ads)']]],
  ['setappsettingsdelegate_3a',['setAppSettingsDelegate:',['../category_spil_07_app_settings_08.html#a0968153d27ced05aad8edfa178b216d9',1,'Spil(AppSettings)']]],
  ['setingameadsdelegate_3a',['setInGameAdsDelegate:',['../category_spil_07_ads_08.html#a6c2fbd35dfe8759b2c43048d66704a5d',1,'Spil(Ads)']]],
  ['setpaymentsdelegate_3a',['setPaymentsDelegate:',['../category_spil_07_payments_08.html#afcd738b20e6b7ced2531fb2d6a5c8557',1,'Spil(Payments)']]],
  ['spil_28abtest_29',['Spil(ABTest)',['../category_spil_07_a_b_test_08.html',1,'']]],
  ['spil_28ads_29',['Spil(Ads)',['../category_spil_07_ads_08.html',1,'']]],
  ['spil_28appsettings_29',['Spil(AppSettings)',['../category_spil_07_app_settings_08.html',1,'']]],
  ['spil_28payments_29',['Spil(Payments)',['../category_spil_07_payments_08.html',1,'']]],
  ['spil_28tracking_29',['Spil(Tracking)',['../category_spil_07_tracking_08.html',1,'']]]
];
