var searchData=
[
  ['paymentsdelegate_2dp',['PaymentsDelegate-p',['../protocol_payments_delegate-p.html',1,'']]]
];
