var searchData=
[
  ['ingameadsdelegate_2dp',['InGameAdsDelegate-p',['../protocol_in_game_ads_delegate-p.html',1,'']]]
];
