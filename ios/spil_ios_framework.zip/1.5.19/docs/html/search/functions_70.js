var searchData=
[
  ['paymentsdidfailtostart_3a',['paymentsDidFailToStart:',['../protocol_payments_delegate-p.html#a4f34b13c2e0d46f53038991b033252b5',1,'PaymentsDelegate-p']]],
  ['paymentsdidreceiveproductlist_3a',['paymentsDidReceiveProductList:',['../protocol_payments_delegate-p.html#aa777dc2d011043fca0ac911f18d0a920',1,'PaymentsDelegate-p']]],
  ['paymentsdidstart',['paymentsDidStart',['../protocol_payments_delegate-p.html#aee086bd8735f7763fa1675b9fdb4e887',1,'PaymentsDelegate-p']]],
  ['paymentsfinishtransaction_3a',['paymentsFinishTransaction:',['../category_spil_07_payments_08.html#a1e02cf77be6ffc1e69ed9ee4a7eab1f7',1,'Spil(Payments)']]],
  ['paymentsrequesttransaction_3aquantity_3a',['paymentsRequestTransaction:quantity:',['../category_spil_07_payments_08.html#a275c8733e6c9537429fcbb4761c5ad6e',1,'Spil(Payments)']]],
  ['paymentstransactiondidfail_3a',['paymentsTransactionDidFail:',['../protocol_payments_delegate-p.html#aaa7f08357ed50b011dbff5411e5fdb87',1,'PaymentsDelegate-p']]],
  ['paymentstransactiondidsucceed_3aforproduct_3a',['paymentsTransactionDidSucceed:forProduct:',['../protocol_payments_delegate-p.html#a6816942ca79d487d93223d020b4dfd22',1,'PaymentsDelegate-p']]]
];
