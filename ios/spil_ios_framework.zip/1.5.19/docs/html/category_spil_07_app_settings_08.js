var category_spil_07_app_settings_08 =
[
    [ "setAppSettingsDelegate:", "category_spil_07_app_settings_08.html#a0968153d27ced05aad8edfa178b216d9", null ]
];