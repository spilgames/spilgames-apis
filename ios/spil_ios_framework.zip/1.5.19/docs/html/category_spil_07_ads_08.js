var category_spil_07_ads_08 =
[
    [ "adsCacheNextInterstitial", "category_spil_07_ads_08.html#ae453132674c2fc1959ac46f8ef2a6344", null ],
    [ "adsCacheNextInterstitial:", "category_spil_07_ads_08.html#ad3c57ef999d4c925a07213f36b28e9f4", null ],
    [ "adsEnabled:", "category_spil_07_ads_08.html#ac633fa5d94b1bf556ccf2076d38110af", null ],
    [ "adsMarkInGameAdAsShown:", "category_spil_07_ads_08.html#a70f854548b1a7280c800136f1afc4d81", null ],
    [ "adsNextInterstitial", "category_spil_07_ads_08.html#a4edc009c2caab10e62503c6c972e7619", null ],
    [ "adsNextInterstitial:", "category_spil_07_ads_08.html#a57078e2d4c5cec1ec9dc4323e9d4c4fd", null ],
    [ "adsRequestInGameAd:", "category_spil_07_ads_08.html#a85024d8c3bc8f5ad5796d7ee9823ea31", null ],
    [ "adsRequestInGameAd:atLocation:", "category_spil_07_ads_08.html#a0fa08111a40290be2e730c24d0ac015d", null ],
    [ "adsRequestInGameAdAsset:", "category_spil_07_ads_08.html#a61683c7f8edb7fcc5eface59216dfe75", null ],
    [ "adsRequestInGameAdAsset:atLocation:", "category_spil_07_ads_08.html#a11bf35f4031a7638c1d48066c89cae5e", null ],
    [ "adsShowMoreGames", "category_spil_07_ads_08.html#adc45ca9bb65ba7f78ff9dacc4e1b42fb", null ],
    [ "setAdsDelegate:", "category_spil_07_ads_08.html#a95416dd0b563d16990628612dc0399a5", null ],
    [ "setInGameAdsDelegate:", "category_spil_07_ads_08.html#a6c2fbd35dfe8759b2c43048d66704a5d", null ]
];