var category_spil_07_payments_08 =
[
    [ "paymentsFinishTransaction:", "category_spil_07_payments_08.html#a1e02cf77be6ffc1e69ed9ee4a7eab1f7", null ],
    [ "paymentsRequestTransaction:quantity:", "category_spil_07_payments_08.html#a275c8733e6c9537429fcbb4761c5ad6e", null ],
    [ "setPaymentsDelegate:", "category_spil_07_payments_08.html#afcd738b20e6b7ced2531fb2d6a5c8557", null ]
];