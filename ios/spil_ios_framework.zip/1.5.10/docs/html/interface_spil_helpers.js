var interface_spil_helpers =
[
    [ "connectionWithURL:onSuccess:onFailure:", "interface_spil_helpers.html#a06484d2d1209dab08d6d159d6d8406e1", null ],
    [ "getAppName", "interface_spil_helpers.html#a83ce222e7edbdd5b4846318d17238c4e", null ],
    [ "getAppVersion", "interface_spil_helpers.html#aa20e59cc60327022e54164d962aea965", null ],
    [ "getCountryCode", "interface_spil_helpers.html#a8a01c3a771327d5cdee04378db039149", null ],
    [ "getDeviceModel", "interface_spil_helpers.html#aa52fc9361fbe63561245ad8a2ed9ddd5", null ],
    [ "getDevicePlatform", "interface_spil_helpers.html#a248e28309828e74932ecf3700075c3f1", null ],
    [ "getLanguage", "interface_spil_helpers.html#ab9fcc243bd45084ce0c2a7fe9f9a3560", null ],
    [ "getMacAddress", "interface_spil_helpers.html#a9431793feb23a3f0646db032345772d7", null ],
    [ "getOSVersion", "interface_spil_helpers.html#acf0260a9b0d8029fdc9b8a7727240b37", null ],
    [ "getPixelRatio", "interface_spil_helpers.html#a9a4b7957cab2bacecc22a0fd0b3abb4b", null ],
    [ "getScreenHeight", "interface_spil_helpers.html#ab89cc95ecb4499403321ac7c185a1e41", null ],
    [ "getScreenWidth", "interface_spil_helpers.html#a3556fd181b5d1ce4798169682884f1f2", null ],
    [ "getUDID", "interface_spil_helpers.html#aae3e7b1362e398a982c8e5985919415f", null ]
];