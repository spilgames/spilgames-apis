var interface_more_games =
[
    [ "initWithContainer:andTracker:", "interface_more_games.html#aa18e26a367d9701b92d88ba716bc1e2a", null ],
    [ "setDelegate:", "interface_more_games.html#a95e3e2af39f00c885b91735f344d8789", null ],
    [ "showMoreGames", "interface_more_games.html#a9c22bf8733b2bba4e25537f2194fd785", null ]
];