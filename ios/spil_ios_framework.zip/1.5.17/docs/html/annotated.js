var annotated =
[
    [ "<AppSettingsDelegate>", "protocol_app_settings_delegate-p.html", "protocol_app_settings_delegate-p" ],
    [ "<InGameAdsDelegate>", "protocol_in_game_ads_delegate-p.html", "protocol_in_game_ads_delegate-p" ],
    [ "Spil(ABTest)", "category_spil_07_a_b_test_08.html", "category_spil_07_a_b_test_08" ],
    [ "Spil(Ads)", "category_spil_07_ads_08.html", "category_spil_07_ads_08" ],
    [ "Spil(AppSettings)", "category_spil_07_app_settings_08.html", "category_spil_07_app_settings_08" ],
    [ "Spil(Tracking)", "category_spil_07_tracking_08.html", "category_spil_07_tracking_08" ]
];