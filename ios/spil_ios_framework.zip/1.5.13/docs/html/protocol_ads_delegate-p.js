var protocol_ads_delegate_p =
[
    [ "adDidAppear", "protocol_ads_delegate-p.html#aab0dde74cd02722be6b90e4f9873150d", null ],
    [ "adDidFailToAppear:", "protocol_ads_delegate-p.html#a46314fbd0ce46103eabdeeb7595fb116", null ],
    [ "adDidFailToStart:", "protocol_ads_delegate-p.html#a28c98a3e0546b7cc65ba4655d32489b8", null ],
    [ "adDidStart", "protocol_ads_delegate-p.html#a2d4e10b7eea8a20f9e8213f3078fac1f", null ],
    [ "adMoreGamesDidAppear", "protocol_ads_delegate-p.html#a4340a3571ab2989c08cc8cbbfbe25b89", null ],
    [ "adMoreGamesDidDismiss", "protocol_ads_delegate-p.html#a3cb471b1a76153bf3a1d8e48477b23a9", null ],
    [ "adMoreGamesDidFailToAppear:", "protocol_ads_delegate-p.html#aca7117d2be0d24ca1923c0185d12174f", null ],
    [ "adMoreGamesWillAppear", "protocol_ads_delegate-p.html#a129ddcbaf7436a8726732f994015e99d", null ],
    [ "adPopupDidDismiss", "protocol_ads_delegate-p.html#ab078c453497ce0bd7dfe277a9f8245fe", null ],
    [ "adWillAppear", "protocol_ads_delegate-p.html#a1bf3d2023665676222ff453d703d57df", null ]
];