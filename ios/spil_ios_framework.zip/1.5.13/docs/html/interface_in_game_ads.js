var interface_in_game_ads =
[
    [ "initWithProvider:andTracker:", "interface_in_game_ads.html#a30f0502431172328220f92ca98f5d99f", null ],
    [ "placeAdOn:at:", "interface_in_game_ads.html#a591a42f55b662fd9a3de842f8ca87266", null ]
];