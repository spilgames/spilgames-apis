var annotated =
[
    [ "ABTestAdapter", "interface_a_b_test_adapter.html", "interface_a_b_test_adapter" ],
    [ "<ABTestDelegate>", "protocol_a_b_test_delegate-p.html", "protocol_a_b_test_delegate-p" ],
    [ "<AdsDelegate>", "protocol_ads_delegate-p.html", "protocol_ads_delegate-p" ],
    [ "<AppSettingsDelegate>", "protocol_app_settings_delegate-p.html", "protocol_app_settings_delegate-p" ],
    [ "<InGameAdsDelegate>", "protocol_in_game_ads_delegate-p.html", "protocol_in_game_ads_delegate-p" ],
    [ "Spil", "interface_spil.html", "interface_spil" ],
    [ "SpilHelpers", "interface_spil_helpers.html", "interface_spil_helpers" ],
    [ "<TrackingExtendedDelegate>", "protocol_tracking_extended_delegate-p.html", "protocol_tracking_extended_delegate-p" ]
];