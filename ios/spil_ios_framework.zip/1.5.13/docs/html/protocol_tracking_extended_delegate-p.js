var protocol_tracking_extended_delegate_p =
[
    [ "trackExtendedDidStart", "protocol_tracking_extended_delegate-p.html#a140144db6978c693f50b7abb97c10da0", null ],
    [ "trackExtendedDidStop", "protocol_tracking_extended_delegate-p.html#abdf0171c6eb0a002b5bb275381d2358c", null ]
];