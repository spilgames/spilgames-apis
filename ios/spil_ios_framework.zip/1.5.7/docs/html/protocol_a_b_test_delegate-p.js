var protocol_a_b_test_delegate_p =
[
    [ "abtestSessionDidEnd", "protocol_a_b_test_delegate-p.html#adc5f87499f8a484a2f6529780d29c81c", null ],
    [ "abtestSessionDidStart", "protocol_a_b_test_delegate-p.html#a1dc02e03972a3373659f29ccc0442b80", null ],
    [ "abtestSessionDiffReceived:", "protocol_a_b_test_delegate-p.html#ab05c8688d6cc151500f52748afb33fd7", null ]
];