var searchData=
[
  ['connectionwithurl_3aonsuccess_3aonfailure_3a',['connectionWithURL:onSuccess:onFailure:',['../interface_spil_helpers.html#a06484d2d1209dab08d6d159d6d8406e1',1,'SpilHelpers']]]
];
